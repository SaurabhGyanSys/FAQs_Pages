import { LightningElement,track } from 'lwc';
import getCustomObjectData from '@salesforce/apex/fetchFaqObjects.getCustomObjectData';


export default class Faq extends LightningElement {
    @track getCustomObjectData;
    @track activeSection;
    @track currentPage = 1;
    @track itemsPerPage = 7;

    connectedCallback() {
        this.fetchCustomObjectData();
    }

    fetchCustomObjectData() {
        getCustomObjectData({ searchQuery: this.searchQuery })
            .then(result => {
                this.getCustomObjectData = result;
                this.activeSection = result[0]?.Section__c;
            })
            .catch(error => {
                console.error('Error fetching FAQ data', error);
            });
    }

    handleSearch(event) {
        this.searchQuery = event.target.value;
        this.fetchCustomObjectData();
    }

    get displayedCustomObjectData() {
        if (!this.getCustomObjectData) {
            return [];
        }

        const startIndex = (this.currentPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        return this.getCustomObjectData.slice(startIndex, endIndex);
    }

    get totalPages() {
        return Math.ceil((this.getCustomObjectData?.length || 0) / this.itemsPerPage);
    }

    handleSectionToggle(event) {
        this.activeSection = event.detail.openSections[0];
    }

    handlePageChange(event) {
        this.currentPage = event.detail.selectedPage;
    }
   
}
