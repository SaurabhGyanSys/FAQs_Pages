import { LightningElement,api } from 'lwc';

export default class FaqPagination extends LightningElement {
    @api totalPages;
    @api currentPage;

    get pages() {
        return Array.from({ length: this.totalPages }, (_, i) => i + 1);
    }

    handlePageClick(event) {
        const selectedPage = parseInt(event.target.label, 10);
        const pageChangeEvent = new CustomEvent('pagechange', {
            detail: { selectedPage }
        });
        this.dispatchEvent(pageChangeEvent);
    }
    getButtonClass(page) {
        const baseClass = 'slds-button';
        const brandClass = 'slds-button_brand';
        const outlineClass = 'slds-button_outline-brand';

        return `${baseClass} ${page === this.currentPage ? brandClass : outlineClass}`;
    }
}